var slide1=document.getElementById("slide1");
var btn=document.getElementById("sbtn1");
var btn2=document.getElementById("sbtn2");
var menu_btn=document.getElementById("btn");
var options=document.getElementById("options");
var home=document.getElementById("home");
var pit=document.getElementById("pit");
var navbar=document.getElementById("navbar");
var opt1=document.getElementById("opt1");
var opt2=document.getElementById("opt2");
var opt3=document.getElementById("opt3");
var opt4=document.getElementById("opt4");
var opt5=document.getElementById("opt5");
// var git=document.getElementById("sb_btn");

// git.addEventListener('click', ()=>{
//     alert("Message received successfully");
// })





if(navbar.style.top=="0")
{
    navbar.style.paddingTop="20px";
    navbar.style.paddingBottom="20px";
    options.style.paddingTop="20px";
    options.style.paddingBottom="20px";
}

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 0 || document.documentElement.scrollTop > 0) {
      document.getElementById("home").style.padding = "10px 15px";
      document.getElementById("opt1").style.padding = "15px 15px";
      document.getElementById("opt2").style.padding = "15px 15px";
      document.getElementById("opt3").style.padding = "15px 15px";
      document.getElementById("opt4").style.padding = "15px 15px";
      document.getElementById("opt5").style.padding = "15px 15px";
      document.getElementById("pit").style.padding = "15px 15px";
      navbar.style.position="fixed";
      navbar.style.top="0";
      options.style.position="fixed";
      options.style.top="0";
      options.style.marginTop="0";
      
    } else {
        document.getElementById("home").style.padding = "25px 15px";
        document.getElementById("opt1").style.padding = "30px 15px";
        document.getElementById("opt2").style.padding = "30px 15px";
        document.getElementById("opt3").style.padding = "30px 15px";
        document.getElementById("opt4").style.padding = "30px 15px";
        document.getElementById("opt5").style.padding = "30px 15px";
        document.getElementById("pit").style.padding = "30px 15px";
        navbar.style.position="initial";
        options.style.position="initial";
      options.style.marginTop="-83px";
    }
  }


menu_btn.addEventListener('click',()=>{
    if(options.style.width=="33vh"){
        options.style.width="0";
        options.style.height="0";
    }else{
        options.style.width="33vh";
    options.style.height="60vh";
    }
    
})


var mgn=1;

btn.addEventListener('click', ()=>{
    if(mgn==1)
    {
        slide1.style.marginLeft="-1934px";
        mgn=7;
    }else if(mgn==7)
    {
        slide1.style.marginLeft="-1608px";
        mgn--;
    }
    else if(mgn==6)
    {
        slide1.style.marginLeft="-1280px";
        mgn--;
    }
    else if(mgn==5)
    {
        slide1.style.marginLeft="-954px";
        mgn--;
    }
    else if(mgn==4)
    {
        slide1.style.marginLeft="-626px";
        mgn--;
    }
    else if(mgn==3)
    {
        slide1.style.marginLeft="-300px";
        mgn--;
    }else if(mgn==2){
        slide1.style.marginLeft="20px";
        mgn=1;
    }
})

btn2.addEventListener('click',()=>{
    if(mgn==1)
    {
        slide1.style.marginLeft="-300px";
        mgn++;
    }else if(mgn==2)
    {
        slide1.style.marginLeft="-626px";
        mgn++;
    }
    else if(mgn==3)
    {
        slide1.style.marginLeft="-954px";
        mgn++;
    }
    else if(mgn==4)
    {
        slide1.style.marginLeft="-1280px";
        mgn++;
    }
    else if(mgn==5)
    {
        slide1.style.marginLeft="-1608px";
        mgn++;
    }
    else if(mgn==6)
    {
        slide1.style.marginLeft="-1934px";
        mgn++;
    }else{
        slide1.style.marginLeft="20px";
        mgn=1;
    }
    // slide1.style.marginLeft="-100px";
})


